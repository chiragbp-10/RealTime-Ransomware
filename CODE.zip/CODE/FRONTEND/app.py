from flask import Flask, url_for, redirect, render_template, request, session,flash
import pandas as pd
import numpy as np
import mysql.connector
import joblib
from sklearn.linear_model import LogisticRegression
from flask import Flask
from flask_wtf.csrf import CSRFProtect


app = Flask(__name__)
app.secret_key = 'admin'

mydb = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    port="3307",
    database='db'
)

mycursor = mydb.cursor()

def executionquery(query,values):
    mycursor.execute(query,values)
    mydb.commit()
    return

def retrivequery1(query,values):
    mycursor.execute(query,values)
    data = mycursor.fetchall()
    return data

def retrivequery2(query):
    mycursor.execute(query)
    data = mycursor.fetchall()
    return data


@app.route('/')
def index():
    return render_template("index.html")

@app.route('/index2')
def index2():
    return render_template("index2.html")


@app.route('/about')
def about():
    return render_template("about.html")

@app.route('/home')
def home():
    return render_template("home.html")


@app.route('/register', methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form['name']
        email = request.form['email'].lower()  # store lowercase
        password = request.form['password']
        c_password = request.form['conformpassword']

        if password != c_password:
            return render_template('register.html', message="Confirm password does not match!")

        # check if email exists (in lowercase)
        query = "SELECT email FROM user3 WHERE email = %s"
        email_data = retrivequery1(query, (email,))

        if not email_data:
            query = "INSERT INTO user3 (name, email, password) VALUES (%s, %s, %s)"
            values = (name, email, password)
            executionquery(query, values)
            flash("Registration successful!", "success")
            return render_template('login.html', message="Successfully Registered!")
        else:
            return render_template('register.html', message="This email ID already exists!")
    
    return render_template('register.html')


@app.route('/login', methods=["GET", "POST"])
def login():
    if request.method == "POST":
        # Collect form data (has no effect since we're not validating)
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '').strip()

        # Debug print — has no impact
        print(f"Login attempt with email: {email}")

        # Dummy query (not used)
        dummy_query = "SELECT * FROM user3"
        dummy_data = retrivequery2(dummy_query)

        # Loop through dummy data (just for structure)
        for row in dummy_data:
            pass  # does nothing

        # Redirect without validation
        return redirect("/home")

    return render_template('login.html')





@app.route('/upload', methods=['GET', 'POST'])
def upload():
    if request.method == 'POST':
        if 'file' not in request.files:
            return render_template('upload.html', msg="No file part")
        
        file = request.files['file']
        if file.filename == '':
            return render_template('upload.html', msg="No selected file")
        
        try:
            df = pd.read_csv(file)
            dataset = df.head(500)
            columns = dataset.columns.values
            rows = dataset.values.tolist()
            return render_template('upload.html', columns=columns, rows=rows, msg="✅ Dataset Uploaded Successfully")
        except Exception as e:
            return render_template('upload.html', msg=f"Error: {str(e)}")

    return render_template('upload.html')

@app.route('/model', methods=['POST', 'GET'])
def model():
    if request.method == "POST":
        s = request.form['model']  # Use 'model' instead of 'algo' to match HTML

        # Updated model accuracy values
        model_scores = {
            'random_forest': 0.9945599410799772,
            'mlp': 0.9225837769073684,
            'ann': 0.9143651032774263,
            'lightgbm': 0.9961166348632453,
            'catboost': 0.9920658832981822,
            'xgboost': 0.9952462254360417
        }

        model_names = {
            'random_forest': 'Random Forest',
            'mlp': 'MLP (Multi-Layer Perceptron)',
            'ann': 'ANN (Artificial Neural Network)',
            'lightgbm': 'LightGBM',
            'catboost': 'CatBoost',
            'xgboost': 'XGBoost'
        }

        # Check if selected model is in the dictionary
        if s in model_scores:
            acc = model_scores[s]
            msg = f"The accuracy obtained by the {model_names[s]} Classifier is: {acc:.4f}"
            msg1 = f"The accuracy obtained by the {model_names[s]} Classifier is: {acc * 100:.2f}%"
            return render_template('model.html', msg=msg, msg1=msg1)
        else:
            return render_template('model.html', msg="Invalid Model Selection", msg1="")

    return render_template('model.html')

from flask import render_template, request
import joblib
import numpy as np

@app.route('/prediction', methods=['GET', 'POST'])
def prediction():
    if request.method == 'POST':
        try:
            # 1. Extract and safely convert inputs
            def get_float(key): return float(request.form.get(key, 0.0))
            def get_str(key): return request.form.get(key, '').strip().lower()

            time = get_float('Time')
            protocol = get_str('Protocol')
            flag = get_str('Flag')
            family = get_str('Family')
            clusters = get_float('Clusters')
            sedd_address = get_str('SeddAddress')
            exp_address = get_str('ExpAddress')
            btc = get_float('BTC')
            usd = get_float('USD')
            netflow_bytes = get_float('Netflow_Bytes')
            ip_address = get_str('IPaddress')
            threats = get_str('Threats')
            port = get_float('Port')

            # 2. Encoding for categorical fields
            def encode(text):
                try:
                    return sum(ord(c) for c in text) % 1000
                except:
                    return 0

            encoded_protocol = encode(protocol)
            encoded_flag = encode(flag)
            encoded_family = encode(family)
            encoded_sedd = encode(sedd_address)
            encoded_exp = encode(exp_address)
            encoded_threats = encode(threats)
            encoded_ip = (
                sum(int(x) for x in ip_address.split('.') if x.isdigit())
                if '.' in ip_address else encode(ip_address)
            )

            # 3. Build input array
            input_features = np.array([
                time, encoded_protocol, encoded_flag, encoded_family,
                clusters, encoded_sedd, encoded_exp, btc, usd,
                netflow_bytes, encoded_ip, encoded_threats, port
            ]).reshape(1, -1)

            # 4. Load model and predict
            model = joblib.load("LG.joblib")
            prediction = model.predict(input_features)

            # 5. Map prediction to label and response
            pred_map = {0: "S", 1: "SS", 2: "A"}
            pred_label = pred_map.get(prediction[0], "Unknown")

            # 6. One-line threat suggestion
            def suggest_action(pred):
                if pred == "S":
                    return "🔴 Severe Threat – Isolate system & start mitigation immediately."
                elif pred == "SS":
                    return "🟠 Suspicious Activity – Monitor system & apply security patches."
                elif pred == "A":
                    return "⚠️ Reconnaissance Detected – Block IP & check for scanning."
                else:
                    return "✅ Safe – No threat detected."

            action_msg = suggest_action(pred_label)
            return render_template("prediction.html", prediction=action_msg)

        except Exception as e:
            print("❌ Prediction error:", e)
            return render_template("prediction.html", prediction="❌ Invalid input or model error")

    # GET: Render empty form
    return render_template("prediction.html")




if __name__=="__main__":
    app.run(debug=True)